### R code from vignette source 'methylKit.Rnw'

###################################################
### code chunk number 1: methylKit.Rnw:60-61
###################################################
read.table( system.file("extdata", "test1.myCpG.txt", package = "methylKit"),header=T,nrows=5)


###################################################
### code chunk number 2: methylKit.Rnw:66-82
###################################################
library(methylKit)
file.list=list( system.file("extdata", "test1.myCpG.txt", package = "methylKit"),
                system.file("extdata", "test2.myCpG.txt", package = "methylKit"),
                system.file("extdata", "control1.myCpG.txt", package = "methylKit"),
                system.file("extdata", "control2.myCpG.txt", package = "methylKit") )


# read the files to a methylRawList object: myobj
myobj=read(file.list,
           sample.id=list("test1","test2","ctrl1","ctrl2"),
           assembly="hg18",
           treatment=c(1,1,0,0),
           context="CpG"
           )




###################################################
### code chunk number 3: methylKit.Rnw:92-96 (eval = FALSE)
###################################################
## my.methRaw=read.bismark(
## 	   location=system.file("extdata", "test.fastq_bismark.sorted.min.sam", 
## 	                    package = "methylKit"),
##              sample.id="test1",assembly="hg18",read.context="CpG",save.folder=getwd())


###################################################
### code chunk number 4: methylKit.Rnw:105-106
###################################################
getMethylationStats(myobj[[2]],plot=F,both.strands=F)


###################################################
### code chunk number 5: methylKit.Rnw:114-115
###################################################
getMethylationStats(myobj[[2]],plot=T,both.strands=F)


###################################################
### code chunk number 6: methylKit.Rnw:126-129
###################################################

library ("graphics")
getCoverageStats(myobj[[2]],plot=T,both.strands=F)


###################################################
### code chunk number 7: methylKit.Rnw:136-138
###################################################
filtered.myobj=filterByCoverage(myobj,lo.count=10,lo.perc=NULL,
                                      hi.count=NULL,hi.perc=99.9)


###################################################
### code chunk number 8: methylKit.Rnw:146-147
###################################################
meth=unite(myobj, destrand=FALSE)


###################################################
### code chunk number 9: methylKit.Rnw:151-152
###################################################
head(meth)


###################################################
### code chunk number 10: methylKit.Rnw:156-159 (eval = FALSE)
###################################################
## # creates a methylBase object. Only CpGs covered at least in 1 sample per group will be returned
## # there were two groups defined by the treatment vector given during the creation of myobj treatment=c(1,1,0,0)
## meth.min=unite(myobj,min.per.group=1L)


###################################################
### code chunk number 11: methylKit.Rnw:166-168
###################################################

getCorrelation(meth,plot=T)


###################################################
### code chunk number 12: methylKit.Rnw:176-178
###################################################

clusterSamples(meth, dist="correlation", method="ward", plot=TRUE)


###################################################
### code chunk number 13: methylKit.Rnw:183-184
###################################################
hc = clusterSamples(meth, dist="correlation", method="ward", plot=FALSE)


###################################################
### code chunk number 14: methylKit.Rnw:189-191
###################################################

PCASamples(meth, screeplot=TRUE)


###################################################
### code chunk number 15: methylKit.Rnw:200-202
###################################################

PCASamples(meth)


###################################################
### code chunk number 16: methylKit.Rnw:217-230
###################################################
# make some batch data frame
# this is a bogus data frame
# we don't have batch information
# for the example data
sampleAnnotation=data.frame(batch_id=c("a","a","b","b"),
                            age=c(19,34,23,40))

as=assocComp(mBase=meth,sampleAnnotation)
as

# construct a new object by removing the first pricipal component
# from percent methylation value matrix
newObj=removeComp(meth,comp=1)


###################################################
### code chunk number 17: methylKit.Rnw:242-253
###################################################
mat=percMethylation(meth)

# do some changes in the matrix
# this is just a toy example
# ideally you want to correct the matrix
# for batch effects
mat[mat==100]=80
 
# reconstruct the methylBase from the corrected matrix
newobj=reconstruct(mat,meth)



###################################################
### code chunk number 18: methylKit.Rnw:259-261
###################################################
tiles=tileMethylCounts(myobj,win.size=1000,step.size=1000)
head(tiles[[1]],3)


###################################################
### code chunk number 19: methylKit.Rnw:266-267
###################################################
myDiff=calculateDiffMeth(meth)


###################################################
### code chunk number 20: methylKit.Rnw:271-280
###################################################
# get hyper methylated bases
myDiff25p.hyper=get.methylDiff(myDiff,difference=25,qvalue=0.01,type="hyper")
#
# get hypo methylated bases
myDiff25p.hypo=get.methylDiff(myDiff,difference=25,qvalue=0.01,type="hypo")
#
#
# get all differentially methylated bases
myDiff25p=get.methylDiff(myDiff,difference=25,qvalue=0.01)


###################################################
### code chunk number 21: methylKit.Rnw:286-287
###################################################
diffMethPerChr(myDiff,plot=FALSE,qvalue.cutoff=0.01, meth.cutoff=25)


###################################################
### code chunk number 22: methylKit.Rnw:295-296 (eval = FALSE)
###################################################
## myDiff=calculateDiffMeth(meth,num.cores=2)


###################################################
### code chunk number 23: methylKit.Rnw:303-309
###################################################
gene.obj=read.transcript.features(system.file("extdata", "refseq.hg18.bed.txt", 
                                           package = "methylKit"))
#
# annotate differentially methylated Cs with promoter/exon/intron using annotation data
#
annotate.WithGenicParts(myDiff25p,gene.obj)


###################################################
### code chunk number 24: methylKit.Rnw:314-323
###################################################
# read the shores and flanking regions and name the flanks as shores 
# and CpG islands as CpGi
cpg.obj=read.feature.flank(system.file("extdata", "cpgi.hg18.bed.txt", 
                                        package = "methylKit"),
                           feature.flank.name=c("CpGi","shores"))
#
#
diffCpGann=annotate.WithFeature.Flank(myDiff25p,cpg.obj$CpGi,cpg.obj$shores,
                                      feature.name="CpGi",flank.name="shores")


###################################################
### code chunk number 25: methylKit.Rnw:330-333
###################################################
promoters=regionCounts(myobj,gene.obj$promoters)

head(promoters[[1]])


###################################################
### code chunk number 26: methylKit.Rnw:341-345
###################################################
diffAnn=annotate.WithGenicParts(myDiff25p,gene.obj)

# target.row is the row number in myDiff25p
head(getAssociationWithTSS(diffAnn))


###################################################
### code chunk number 27: methylKit.Rnw:350-351
###################################################
getTargetAnnotationStats(diffAnn,percentage=TRUE,precedence=TRUE)


###################################################
### code chunk number 28: methylKit.Rnw:358-361
###################################################

plotTargetAnnotation(diffAnn,precedence=TRUE,
    main="differential methylation annotation")


###################################################
### code chunk number 29: methylKit.Rnw:369-372
###################################################

plotTargetAnnotation(diffCpGann,col=c("green","gray","white"),
       main="differential methylation annotation")


###################################################
### code chunk number 30: methylKit.Rnw:378-379
###################################################
getFeatsWithTargetsStats(diffAnn,percentage=TRUE)


###################################################
### code chunk number 31: methylKit.Rnw:386-390
###################################################
class(meth)
as(meth,"GRanges")
class(myDiff)
as(myDiff,"GRanges")


###################################################
### code chunk number 32: methylKit.Rnw:396-398
###################################################
select(meth,1:5) # get first 10 rows of a methylBase object
myDiff[21:25,] # get 5 rows of a methylDiff object


###################################################
### code chunk number 33: methylKit.Rnw:403-407 (eval = FALSE)
###################################################
## # creates a new methylRawList object
## myobj2=reorganize(myobj,sample.ids=c("test1","ctrl2"),treatment=c(1,0) )
## # creates a new methylBase object
## meth2 =reorganize(meth,sample.ids=c("test1","ctrl2"),treatment=c(1,0) )


###################################################
### code chunk number 34: methylKit.Rnw:412-414 (eval = FALSE)
###################################################
## # creates a matrix containing percent methylation values
## perc.meth=percMethylation(meth)


###################################################
### code chunk number 35: methylKit.Rnw:496-497
###################################################
sessionInfo() 


