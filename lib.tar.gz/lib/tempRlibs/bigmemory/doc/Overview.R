### R code from vignette source 'Overview.Rnw'

###################################################
### code chunk number 1: setup
###################################################
options(keep.source = TRUE, width = 75)


